#include "../../features.hpp"

/// <summary>
/// to be implemented after
///	lagcompensation
/// </summary>
/// <returns></returns>
c_lag_record* c_target::select_best_record() {

	return nullptr;
}