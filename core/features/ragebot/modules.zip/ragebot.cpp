#include "../features.hpp"

void c_ragebot::run(c_usercmd* cmd)
{

}

c_ragebot* ragebot = new c_ragebot();